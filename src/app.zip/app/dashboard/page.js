"use client";

import { useEffect, useState } from "react";

export default function Dashboard() {

  const [expenses, setExpenses] = useState([]);

  useEffect(() => {
    const stored = JSON.parse(localStorage.getItem("expenses")) || [];
    setExpenses(stored);
  }, []);

  const total = expenses.reduce(
    (sum, e) => sum + Number(e.amount),
    0
  );

  return (
    <div className="min-h-screen bg-gray-100 p-8">

      <h1 className="text-3xl font-bold mb-8 text-gray-800">
        Expense Dashboard
      </h1>

      <div className="grid md:grid-cols-3 gap-6">

        <div className="bg-white p-6 rounded-xl shadow-md">
          <h3 className="text-gray-500">Total Expenses</h3>
          <p className="text-2xl font-bold text-indigo-600">
            ₹{total}
          </p>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-md">
          <h3 className="text-gray-500">Transactions</h3>
          <p className="text-2xl font-bold text-indigo-600">
            {expenses.length}
          </p>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-md">
          <h3 className="text-gray-500">Average Expense</h3>
          <p className="text-2xl font-bold text-indigo-600">
            ₹{expenses.length ? Math.round(total / expenses.length) : 0}
          </p>
        </div>

      </div>

    </div>
  );
}