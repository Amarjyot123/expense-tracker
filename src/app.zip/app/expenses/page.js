"use client";

import { useState } from "react";

export default function Page() {

  const [title, setTitle] = useState("");
  const [amount, setAmount] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();

    const expense = {
      title: title,
      amount: amount
    };

    console.log(expense);
    alert("Expense Added Successfully!");

    setTitle("");
    setAmount("");
  };

  return (
    <div className="flex justify-center items-center h-screen bg-gray-100">

      <form
        onSubmit={handleSubmit}
        className="bg-white p-8 rounded-xl shadow-lg w-[420px]"
      >

        <h2 className="text-2xl font-bold mb-6 text-center">
          Add Expense
        </h2>

        <input
          type="text"
          placeholder="Expense Title"
          className="border p-2 w-full mb-4"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          required
        />

        <input
          type="number"
          placeholder="Amount"
          className="border p-2 w-full mb-4"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
          required
        />

        <button
          type="submit"
          className="bg-blue-500 text-white px-4 py-2 rounded w-full"
        >
          Add Expense
        </button>

      </form>

    </div>
  );
}