import "./globals.css";
import { Toaster } from 'react-hot-toast';  // ← ADD THIS LINE
import Navbar from "./components/Navbar";

export const metadata = {
  title: "Expense Tracker",
  description: "Track your expenses easily",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body className="antialiased">
        <Navbar />
        <div className="p-6">
          {children}
        </div>
        {/* ADD TOASTER HERE - Assignment 6 requirement */}
        <Toaster 
          position="top-right"
          reverseOrder={false}
          toastOptions={{
            duration: 4000,
            style: {
              background: 'rgba(0,0,0,0.95)',
              color: '#fff',
              backdropFilter: 'blur(20px)',
              borderRadius: '16px',
              border: '1px solid rgba(255,255,255,0.2)',
            },
          }}
        />
      </body>
    </html>
  );
}
