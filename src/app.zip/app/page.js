import Link from "next/link";

export default function Home() {
  return (
    <div className="flex flex-col items-center justify-center text-white text-center mt-24 px-6">

      <h1 className="text-5xl font-bold mb-6">
        Expense Tracker 💰
      </h1>

      <p className="text-lg max-w-xl mb-10 opacity-80">
        Track your spending, visualize your expenses and manage
        your finances in a smart and simple way.
      </p>

      <div className="flex gap-6">

        <Link href="/add-expense">
          <button className="bg-green-500 hover:bg-green-600 px-6 py-3 rounded-lg font-semibold">
            Add Expense
          </button>
        </Link>

        <Link href="/expenses">
          <button className="bg-blue-500 hover:bg-blue-600 px-6 py-3 rounded-lg font-semibold">
            View Expenses
          </button>
        </Link>

      </div>

    </div>
  );
}